addEventListener("DOMContentLoaded", event => {
    const article = document.querySelector("article");
    article.innerHTML = "ich war da";
});
