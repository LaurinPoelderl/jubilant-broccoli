export type Todo = {
  readonly userId: number;
  readonly id: number;
  readonly title: string;
  readonly completed: boolean;
};

