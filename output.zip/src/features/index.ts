export { Model } from "./model";
export { store } from "./model";
export const BASE_URL = "https://jsonplaceholder.typicode.com/";
