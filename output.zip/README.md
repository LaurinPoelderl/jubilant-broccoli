# Lösung von:
- Manuel Puchner
- Josef Stieg
- Jakob Schlager
